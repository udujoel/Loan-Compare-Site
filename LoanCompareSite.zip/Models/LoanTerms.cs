﻿namespace LoanCompareSite.Models
{
    public class Loanterms
    {
        public int id { get; set; }
        public string name { get; set; }
        public string package { get; set; }
        public int count { get; set; }
        public double rate { get; set; }
        public string terms { get; set; }
        public string website { get; set; }
        public int duration { get; set; }
    }
}