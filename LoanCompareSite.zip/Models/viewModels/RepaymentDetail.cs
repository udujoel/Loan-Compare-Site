﻿namespace LoanCompareSite.Models.viewModels
{
    public class RepaymentDetail
    {
        public double total { get; set; }
        public double balance { get; set; }
        public int monthno { get; set; }
        public double amountToPay { get; set; }
        public int payPercent { get; set; }

    }
}